// SS628DDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "XPButton.h"

// CSS628DDlg �Ի���
class CSS628DDlg : public CDialog
{
// ����
public:
	CSS628DDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_SS628D_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//{{AFX_MSG(CSS628DDlg)
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnButton6();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	BOOL m_bReadError;
	BOOL m_bWriteError;
	void CloseConnection(void);
protected:
	HANDLE hUSBRead;
	HANDLE hUSBWrite;
public:
	afx_msg void OnBnClickedCancel();
	BYTE m_byteLength;
	afx_msg void OnEnKillfocusEdit1();
	CString m_strAddr;
	CString m_strBegin;
	CString m_strName;
	CString m_strSex;
	CString m_strFolk;
	CString m_strIDNum;
	CString m_strDep;
	CString m_strBirth;
	CString m_strEnd;
	CString m_strNewAddr;
	CString m_zhiwen;
public:
protected:

public:
	CStatic m_ctPicTest;
	afx_msg void OnTimer(UINT nIDEvent);
	CXPButton BTreadcard;
	CString m_strMsg;
	CStatic m_ctMsg;
	CXPButton BTreadNew;
	CXPButton m_ctBtnExit;
};
