//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SS628D.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SS628D_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_XGC                  129
#define IDB_BITMAP_JY                   131
#define IDR_IMAGE1                      132
#define IDC_MYPIC_JY                    133
#define ID_MYPIC_JY                     133
#define ID_MYPIC_XGC                    134
#define IDB_BITMAP1                     135
#define IDB_BITMAP_BLANK                135
#define IDR_IMAGE2                      137
#define ID_MYPIC_BG                     138
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_EDIT_NAME                   1002
#define IDC_EDIT_FOLK                   1003
#define IDC_EDIT_SEX                    1004
#define IDC_EDIT_BIRTH                  1005
#define IDC_EDIT_ADDR                   1006
#define IDC_EDIT_IDNUM                  1007
#define IDC_EDIT_NEWADDR                1008
#define IDC_EDIT_DEP                    1009
#define IDC_EDIT_BEGIN                  1010
#define IDC_EDIT_END                    1011
#define IDC_STATIC_PIC                  1012
#define IDC_EDIT_zhiwen                 1012
#define IDC_STATIC_TEST                 1013
#define IDC_TEST                        1015
#define IDC_BUTTON2                     1016
#define IDC_ST_MSG                      1018
#define IDC_CUSTOM1                     1019
#define IDC_BUTTON3                     1020
#define IDC_BUTTON4                     1021
#define IDC_BUTTON6                     1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
